<?php

$page = "Data Rute";
session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if ($_SESSION["roles"] !== "Admin") {
    echo "
    <script type='text/javascript'>
        alert('Maaf, Anda tidak memiliki izin untuk mengakses halaman ini.');
        window.location = '../../index.php';
    </script>
    ";
    exit();
}

$rute = query("SELECT * FROM rute INNER JOIN maskapai ON maskapai.id_maskapai = rute.id_maskapai ORDER BY rute_asal");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="main-content mt-5">
    <h1 class="text-center fw-bold fs-2 mb-3">Data Rute</h1>
    <a href="tambah.php" class="btn btn-primary mb-3">Tambah Rute</a>
    <div class="table-responsive">
        <table class="table table-striped table-bordered border border-2">
            <thead>
                <tr>
                    <th scope="col" class="text-center align-middle">No</th>
                    <th scope="col" class="text-center align-middle">Nama Maskapai</th>
                    <th scope="col" class="text-center align-middle">Rute Asal</th>
                    <th scope="col" class="text-center align-middle">Rute Tujuan</th>
                    <th scope="col" class="text-center align-middle">Tanggal Pergi</th>
                    <th scope="col" class="text-center align-middle">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php foreach ($rute as $data) : ?>
                    <tr>
                        <td class="text-center align-middle"><?= $no; ?></td>
                        <td class="text-center align-middle"><?= $data["nama_maskapai"]; ?></td>
                        <td class="text-center align-middle"><?= $data["rute_asal"]; ?></td>
                        <td class="text-center align-middle"><?= $data["rute_tujuan"]; ?></td>
                        <td class="text-center align-middle"><?= $data["tanggal_pergi"]; ?></td>
                        <td class="text-center align-middle">
                            <a href="edit.php?id=<?= $data["id_rute"]; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="hapus.php?id=<?= $data["id_rute"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                    <?php $no++; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>