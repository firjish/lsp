<?php

session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if (isset($_POST["tambah"])) {
    if (tambah($_POST) > 0) {
        echo "
            <script type='text/javascript'>
                alert('Yay! data rute berhasil ditambahkan!')
                window.location = 'index.php'
            </script>
        ";
    } else {
        echo "
            <script type='text/javascript'>
                alert('Yhaa .. data rute gagal ditambahkan :(')
                window.location = 'index.php'
            </script>
        ";
    }
}

$maskapai = query("SELECT * FROM maskapai");
$kota = query("SELECT * FROM kota");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="main-content mt-5">
    <h1 class="text-center fw-bold fs-2 mb-4">Tambah Rute</h1>
    <form action="" method="POST" class="border border-2 rounded p-4">
        <div class="mb-3">
            <label for="nama_maskapai" class="form-label">Nama Maskapai</label>
            <select name="id_maskapai" id="id_maskapai" class="form-select">
                <?php foreach ($maskapai as $data) : ?>
                    <option value="<?= $data["id_maskapai"]; ?>"><?= $data["nama_maskapai"]; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="rute_asal" class="form-label">Rute Asal</label>
            <select name="rute_asal" id="rute_asal" class="form-select">
                <?php foreach ($kota as $data) : ?>
                    <option value="<?= $data["nama_kota"]; ?>"><?= $data["nama_kota"]; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="rute_tujuan" class="form-label">Rute Tujuan</label>
            <select name="rute_tujuan" id="rute_tujuan" class="form-select">
                <?php foreach ($kota as $data) : ?>
                    <option value="<?= $data["nama_kota"]; ?>"><?= $data["nama_kota"]; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="tanggal_pergi" class="form-label">Tanggal Pergi</label>
            <input type="date" name="tanggal_pergi" id="tanggal_pergi" class="form-control">
        </div>
        <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
    </form>
</div>