$(document).ready(function () {
    $("#register-link").click(function (event) {
        event.preventDefault();

        $(".login-container").fadeOut(500, function () {
            window.location.href = "../register/index.php";
        });
    });
});