<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="/e-ticketing/assets/libraries/bootstrap/css/bootstrap.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <title>Register Form</title>
</head>

<body>
    <div class="container">
        <div class="register-container">
            <div class="logo text-center">
                <span>E - Ticketing</span>
            </div>
            <h2 class="text-secondary fs-5">Register your account</h2>
            <form action="process.php" method="POST" id="register-form">
                <div class="form-group">
                    <input type="text" name="username" id="username" class="form-control" placeholder="Username" required>
                </div>
                <div class="form-group">
                    <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" placeholder="Nama Lengkap" required>
                </div>
                <div class="form-group">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
                </div>
                <button type="submit" class="btn btn-register">Register</button>
            </form>
            <div class="login-link">
                <p>Already have an account? <a href="../login/index.php" id="login-link" onclick="goToLoginPage()">Login</a></p>
            </div>
        </div>
    </div>

    <script src="/e-ticketing/assets/libraries/jquery/dist/jquery.min.js"></script>

    <script src="script.js"></script>
</body>

</html>