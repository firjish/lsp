<?php

$page = "Beranda";

require 'layouts/navbar.php';

?>

<?php

if (isset($_POST['cari'])) {
    $keyword = $_POST['cariJadwal'];

    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
    INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
    INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
    WHERE nama_maskapai LIKE '%$keyword%' OR rute_asal LIKE '%$keyword%' OR rute_tujuan LIKE '%$keyword%' 
    ORDER BY tanggal_pergi, waktu_berangkat");
} else {
    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
    INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
    INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");
}
?>

<style>
    .hero-bg {
        background-image: url('assets/images/hero-bg.jpeg');
        background-size: cover;
        background-position: center;
        padding-top: 260px;
        padding-bottom: 100px;
    }
</style>

<div class="container-fluid hero-bg">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="hero text-center">
                    <h1 class="text-light display-5 fs-2 mb-4">Temukan Penerbangan Anda</h1>
                    <form action="" method="POST" class="mb-4">
                        <div class="input-group">
                            <input type="text" class="form-control" name="cariJadwal" placeholder="Search">
                            <button class="btn btn-primary" type="submit" name="cari">Cari</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <h2 class="mb-4">Jadwal Penerbangan</h2>
    <div class="list-tiket-pesawat-scroll" style="overflow-x: auto;">
        <div class="list-tiket-pesawat d-flex flex-nowrap pl-3" style="gap: 2rem;"> <!-- Menambahkan style="gap: 1rem;" untuk memberikan ruang antara card -->
            <?php foreach ($jadwalPenerbangan as $index => $data) : ?>
                <div class="col mb-4" style="flex: 0 0 auto;">
                    <a href="detail.php?id=<?= $data["id_jadwal"]; ?>" class="text-decoration-none text-dark">
                        <div class="card shadow" style="max-width: 13rem;">
                            <img src="assets/images/<?= $data["logo_maskapai"]; ?>" class="card-img-top" alt="<?= $data["nama_maskapai"]; ?>" height="150">
                            <div class="card-body">
                                <h5 class="card-title"><?= $data["nama_maskapai"]; ?></h5>
                                <p class="card-text"><?= $data["tanggal_pergi"]; ?></p>
                                <p class="card-text"><?= $data["waktu_berangkat"]; ?> - <?= $data["waktu_tiba"]; ?></p>
                                <p class="card-text"><?= $data["rute_asal"] ?> - <?= $data["rute_tujuan"]; ?></p>
                                <p class="card-text">Rp <?= number_format($data["harga"]); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
        <span class="text-muted">© 2024 E-Ticketing</span>
    </div>
</footer>