<?php

$page = "Jadwal Penerbangan";

require 'layouts/navbar.php';

?>

<?php

if (isset($_POST['cari'])) {
    $keyword = $_POST['cariJadwal'];

    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
    INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
    INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
    WHERE nama_maskapai LIKE '%$keyword%' OR rute_asal LIKE '%$keyword%' OR rute_tujuan LIKE '%$keyword%' 
    ORDER BY tanggal_pergi, waktu_berangkat");
} else {
    $jadwalPenerbangan = query("SELECT * FROM jadwal_penerbangan 
    INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
    INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");
}
?>

<div class="container mt-5">
    <h2 class="mb-4">Jadwal Penerbangan</h2>
    <div class="list-tiket-pesawat">
        <div class="row">
            <?php foreach ($jadwalPenerbangan as $index => $data) : ?>
                <div class="col-md-3 mb-4">
                    <a href="detail.php?id=<?= $data["id_jadwal"]; ?>" class="text-decoration-none text-dark">
                        <div class="card shadow">
                            <img src="assets/images/<?= $data["logo_maskapai"]; ?>" class="card-img-top" alt="<?= $data["nama_maskapai"]; ?>" height="215">
                            <div class="card-body">
                                <h5 class="card-title"><?= $data["nama_maskapai"]; ?></h5>
                                <p class="card-text"><?= $data["tanggal_pergi"]; ?></p>
                                <p class="card-text"><?= $data["waktu_berangkat"]; ?> - <?= $data["waktu_tiba"]; ?></p>
                                <p class="card-text"><?= $data["rute_asal"] ?> - <?= $data["rute_tujuan"]; ?></p>
                                <p class="card-text">Rp <?= number_format($data["harga"]); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<footer class="footer mt-auto py-3 bg-light">
    <div class="container text-center">
        <span class="text-muted">© 2024 E-Ticketing</span>
    </div>
</footer>